﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PersonelKayıtSQL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //SQL Server bağlatı keyini güncelle
        SqlConnection baglanti = new SqlConnection("Data Source=lesponnspc\\LETECH;Initial Catalog=PersonelVeriTabani;Integrated Security=True;Encrypt=False");

        void temizle()
        {
            txtID.Text = "";
            txtAd.Text = "";
            txtSoyad.Text = "";
            cmbSehir.SelectedIndex = 0;
            mskMaas.Text = "";
            txtMeslek.Text = "";
            rbEvli.Checked = true;
            rbBekar.Checked = false;
            txtMedeni.Text = "Medeni Durum";


        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personelVeriTabaniDataSet.Tbl_Personel' table. You can move, or remove it, as needed.
            //Yukarıda ki yorum satırı alttaki otmatik yazılan kodu açıklamaktadır. "Uygulama açıldığında tablo otomatik olarak yüklenmektedir."
            this.tbl_PersonelTableAdapter.Fill(this.personelVeriTabaniDataSet.Tbl_Personel);
            txtID.Text = "";

        }

        private void listele_Click(object sender, EventArgs e)
        {
            this.tbl_PersonelTableAdapter.Fill(this.personelVeriTabaniDataSet.Tbl_Personel);

            MessageBox.Show("Listelendi.");
        }

        private void kaydet_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            
            SqlCommand SQLKomutEkle = new SqlCommand("insert into Tbl_Personel (PerAd, PerSoyad, PerSehir, PerMaas, PerMeslek) values (@Ad, @Soyad, @Sehir, @Maas, @Meslek)",baglanti);

            SQLKomutEkle.Parameters.AddWithValue("@Ad", txtAd.Text);
            SQLKomutEkle.Parameters.AddWithValue("@Soyad", txtSoyad.Text);
            SQLKomutEkle.Parameters.AddWithValue("@Sehir", cmbSehir.Text);
            SQLKomutEkle.Parameters.AddWithValue("@Maas", mskMaas.Text);
            SQLKomutEkle.Parameters.AddWithValue("@Meslek", txtMeslek.Text);
            SQLKomutEkle.ExecuteNonQuery();

            baglanti.Close();
            this.tbl_PersonelTableAdapter.Fill(this.personelVeriTabaniDataSet.Tbl_Personel);

            MessageBox.Show("Personel Başarıyla Eklendi.");
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedDGV = dataGridView1.SelectedCells[0].RowIndex;

            txtID.Text = dataGridView1.Rows[selectedDGV].Cells[0].Value.ToString();
            txtAd.Text = dataGridView1.Rows[selectedDGV].Cells[1].Value.ToString();
            txtSoyad.Text = dataGridView1.Rows[selectedDGV].Cells[2].Value.ToString();
            cmbSehir.Text = dataGridView1.Rows[selectedDGV].Cells[3].Value.ToString();
            mskMaas.Text = dataGridView1.Rows[selectedDGV].Cells[4].Value.ToString();
            txtMedeni.Text = dataGridView1.Rows[selectedDGV].Cells[5].Value.ToString();
            txtMeslek.Text = dataGridView1.Rows[selectedDGV].Cells[6].Value.ToString();
        }

        private void txtMedeni_TextChanged(object sender, EventArgs e)
        {
            if (txtMedeni.Text == "Evli")
            {
                rbEvli.Checked = true;
                rbBekar.Checked = false;
            }
            if (txtMedeni.Text == "Bekar")
            {
                rbEvli.Checked = false;
                rbBekar.Checked = true;
            }
        }

        private void rbEvli_CheckedChanged(object sender, EventArgs e)
        {
            if (rbEvli.Checked == true)
            {
                txtMedeni.Text = "Evli";
            }
        }

        private void rbBekar_CheckedChanged(object sender, EventArgs e)
        {
            if (rbBekar.Checked == true)
            {
                txtMedeni.Text = "Bekar";
            }
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            SqlCommand SQLKomutSil = new SqlCommand("delete from Tbl_Personel where PersonelID = @ID",baglanti);

            SQLKomutSil.Parameters.AddWithValue("@ID",txtID.Text);
            SQLKomutSil.ExecuteNonQuery();

            baglanti.Close();
            this.tbl_PersonelTableAdapter.Fill(this.personelVeriTabaniDataSet.Tbl_Personel);

            MessageBox.Show("Personel Kaydı Başarıyla Silindi.");
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            SqlCommand SQLServerGuncelle = new SqlCommand("update Tbl_Personel set PerAd=@Ad, PerSoyad=@Soyad, PerSehir=@Sehir, PerMaas=@Maas, PerDurum=@Durum, PerMeslek=@Meslek where PersonelId=@ID",baglanti);
            
            SQLServerGuncelle.Parameters.AddWithValue("@Ad",txtAd.Text);
            SQLServerGuncelle.Parameters.AddWithValue("@Soyad", txtSoyad.Text);
            SQLServerGuncelle.Parameters.AddWithValue("@Sehir",cmbSehir.Text);
            SQLServerGuncelle.Parameters.AddWithValue("@Maas", mskMaas.Text);
            SQLServerGuncelle.Parameters.AddWithValue("@Durum", txtMedeni.Text);
            SQLServerGuncelle.Parameters.AddWithValue("@Meslek", txtMeslek.Text);
            SQLServerGuncelle.Parameters.AddWithValue("@ID",txtID.Text);

            SQLServerGuncelle.ExecuteNonQuery();

            baglanti.Close();
            this.tbl_PersonelTableAdapter.Fill(this.personelVeriTabaniDataSet.Tbl_Personel);

            MessageBox.Show("Personel Bilgileri Başarıyla Güncellendi.");
        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            temizle();
        }
    }
}
